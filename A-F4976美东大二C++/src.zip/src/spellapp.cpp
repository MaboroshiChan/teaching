// your copyright...description....includes...


void printMenu(); // prints menu when program starts


int main() {

// implement your solution...use the functions from the spellchecker.h header file


}


void printMenu() {

}
