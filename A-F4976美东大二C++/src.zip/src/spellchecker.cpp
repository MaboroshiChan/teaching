// provide implementation to the functions in spellchecker.h
// no main() in this file

#include "spellchecker.h"

