package DataStructure;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.Queue;

import java.util.PriorityQueue;

public class GraphAlgorithms {

    private int[][] edges; // store edges passing in
    private int[][] adj_matrix; // adjacent matrix used for edge length inquery solely
    private HashSet<Integer>[] adj_list; // adjacent list used for traversing.
    private int size; // #vertex
    private int[] dist = null; // minimum distance from source in Dijsktra algorithm
    private Integer[] prev = null; // previous vertex of a vertex in shortest path.

    final int PERMENENT = 2;
    final int TEMPORARY = 1;
    final int UNMARKED = 0;
    final int INFINITY = 2 << 10;

    interface Traverse {
        void apply(int top, boolean[] visited);
    }

    int[][] get_matrix() {
        return adj_matrix;
    }

    HashSet<Integer>[] get_list() {
        return adj_list;
    }

    GraphAlgorithms(int[][] edges, int size, boolean direct) { // initialization
        this.size = size;
        this.edges = edges;
        adj_matrix = make_adjacent_matrix(edges, direct); // initialize matrix
        adj_list = make_graph(edges, size, direct); // initialize adjacent list
        System.out.println("size = " + size + " is direct: " + direct);
    }

    /**
     * make adjacent list
     * 
     * @param edges
     * @param size
     * @param direct is the graph direct or undirect
     * @return
     */
    private HashSet<Integer>[] make_graph(int[][] edges, int size, boolean direct) {
        HashSet<Integer>[] res = new HashSet[size];
        for (int i = 0; i < size; ++i) {
            res[i] = new HashSet<>();
        }
        for (int e = 0; e < edges.length; ++e) {
            int v1 = edges[e][0];
            int v2 = edges[e][1];

            res[v1].add(v2);
            if (!direct) {
                res[v2].add(v1);
            }
        }
        return res;
    }

    /**
     * make adjacent matrix
     * 
     * @param edges
     * @param direct
     * @return adjacent matrix
     */
    private int[][] make_adjacent_matrix(int[][] edges, boolean direct) {
        int[][] matrix = new int[size][size];
        for (int i = 0; i < edges.length; ++i) {
            int v1 = edges[i][0];
            int v2 = edges[i][1];
            matrix[v1][v2] = edges[i][2];
            if (!direct) {
                matrix[v2][v1] = edges[i][2];
            }
        }
        return matrix;
    }

    /**
     * perform BFS
     * 
     * @param func callback function when visiting a vertex.
     */
    void bfs(Traverse func) {
        Queue<Integer> queue = new LinkedList<>(); // queue for bfs
        boolean[] visited = new boolean[this.size];
        Arrays.fill(visited, false);
        for (int v = 0; v < size; ++v) {
            if (visited[v])
                continue;
            visited[v] = true;
            queue.add(v);
            while (!queue.isEmpty()) {
                int top = queue.poll();
                // do sometthing
                func.apply(top, visited);
                HashSet<Integer> adjcents = this.adj_list[top]; // retrieve adjacent list
                for (int w : adjcents) {
                    if (visited[w])
                        continue;
                    queue.add(w);
                    visited[w] = true;
                }
            }
        }
    }

    /**
     * Helper function for dfs, used for recursion.
     * 
     * @param top     currently visiting vertex
     * @param visited array of visited or unvisited vertices
     * @param func    callback function.
     */
    void dfs_helper(int top, boolean[] visited, Traverse func) {
        visited[top] = true;
        HashSet<Integer> adj = this.adj_list[top]; // retrieve adjacent list.
        func.apply(top, visited); // apply callback function
        for (int x : adj) {
            if (!visited[x]) {
                dfs_helper(x, visited, func);
            }
        }
    }

    /**
     * DFS search from vertex 0
     * 
     * @param func callback function
     */
    void dfs(Traverse func) {
        boolean[] visited = new boolean[this.size];
        Arrays.fill(visited, false);
        for (int v = 0; v < this.size; ++v) {
            if (visited[v])
                continue;
            dfs_helper(v, visited, func);
        }
    }

    /**
     * topological sort
     * 
     * @param v       starting vertex
     * @param result  result of topological sort
     * @param visited visited or unvisited vertex.
     * @throws Exception
     */
    void topo_dfs(int v, LinkedList<Integer> result, int[] visited) throws Exception {
        if (visited[v] == PERMENENT) { // if the current vertex has permanent mark, stop dfs here then.
            return;
        }
        if (visited[v] == TEMPORARY) { // if the current vertex is temporary, then the graph has a cycle
            throw new Exception("The graph has cycle. Cannot perform topological sort.");
        }
        visited[v] = TEMPORARY;
        var adj = this.adj_list[v];
        for (int m : adj) {
            topo_dfs(m, result, visited);
        }
        visited[v] = PERMENENT;
        result.addFirst(v);
    }

    /**
     * topological sort main function starting at vertex A.
     * 
     * @return
     * @throws Exception
     */
    LinkedList<Integer> topological_sort() throws Exception {
        LinkedList<Integer> sorted = new LinkedList<>();
        int[] visited = new int[this.size];
        for (int v = 0; v < this.size; ++v) {
            if (visited[v] == 0) {
                topo_dfs(v, sorted, visited);
            }
        }
        return sorted;
    }

    /**
     * Dijkstra algorithm starting at source vertex.
     * 
     * @param source
     */
    void djikstra(int source) {
        int[] dist = new int[this.size];
        Integer[] prev = new Integer[this.size];
        Arrays.fill(dist, this.INFINITY);
        Arrays.fill(prev, null);

        LinkedList<Integer> pq = new LinkedList<>();

        for (int v = 0; v < this.size; ++v) {
            pq.add(v);
        }

        dist[source] = 0;
        while (!pq.isEmpty()) {
            pq.sort(new Comparator<Integer>() {

                @Override
                public int compare(Integer o1, Integer o2) {

                    return dist[o1] - dist[o2];
                }

            });

            int u = pq.poll();
            var neighbours = this.adj_list[u];
            for (int v : neighbours) {

                int alt = dist[u] + this.adj_matrix[u][v];
                // if(v == 3){
                // System.out.println("u = " + u + " dist[u]: " + dist[u] + " dist[u][v]: " +
                // this.adj_matrix[u][v]);
                // }
                if (alt < dist[v]) {
                    dist[v] = alt;
                    prev[v] = u;
                }
            }
        }

        this.prev = prev;
        this.dist = dist;
        System.out.println("Dijkstra result");
        System.out.println("previous node array " + Arrays.toString(prev));
        System.out.println("shortest path to node i " + Arrays.toString(dist));
        System.out.println("");
    }

    /**
     * Data structure of an Edge
     * `src`---->`end`, with cost or length or value or distance `dist`.
     */
    class Edge {
        public int src; // source
        public int end; // end
        public int dist;

        Edge(int _src, int _end, int _dist) {
            src = _src;
            end = _end;
            dist = _dist;
        }

    }

    /**
     * Prim algorithm. Implement according to pseudo-code written on Wikipedia.
     * 
     * @param source
     * @return an ArrayList of minimum spanning tree.
     */
    ArrayList<Edge> prim(int source) {

        // Initialization
        ArrayList<Edge> result = new ArrayList<>(); // result arraylist
        ArrayList<Integer> vertices = new ArrayList<>(this.size); // initialize V_new

        boolean[] visited = new boolean[size];
        Arrays.fill(visited, false);

        PriorityQueue<Edge> pq = new PriorityQueue<>(edges.length, new Comparator<Edge>() { // priority queue for
                                                                                            // selecting
                                                                                            // edges with minimum cost.
            @Override
            public int compare(Edge e1, Edge e2) {
                return e1.dist - e2.dist;
            }

        });

        vertices.add(source); // add source new vertex to V_new
        visited[source] = true; // mark this vertex

        var adj = this.adj_list[source]; // insert all edges connected to source.
        for (int e : adj) {
            pq.add(new Edge(source, e, this.adj_matrix[source][e]));
        }
        // end of Initialization.

        while (vertices.size() < this.size) {
            Edge min_e = pq.poll(); // take the min
            int u = min_e.end;
            vertices.add(u); // add new v to V_new
            visited[u] = true;
            result.add(min_e);
            var e_adj = this.adj_list[u];
            e_adj.forEach(x -> { // add neibourhoods of u if they are not in V_new.

                if (!visited[x]) {
                    pq.add(new Edge(u, x, this.adj_matrix[u][x]));
                }
            });

        }
        int total_cost = 0; // computing total_cost of this minimum spanning tree.
        for (int r = 0; r < result.size(); ++r) {
            var get_r = result.get(r);
            total_cost += get_r.dist;
        }

        System.out.println("");
        System.out.println("prime total cost = " + total_cost);

        return result;
    }

    // union find
    int find(int[] parent, int p) {
        while (p != parent[p]) {
            parent[p] = parent[parent[p]]; // path compression by halving
            p = parent[p];
        }
        return p;
    }

    void Union(int[] parent, int x, int y) {
        int xset = find(parent, x);
        int yset = find(parent, y);
        parent[xset] = yset;
    }

    /**
     * kruskal algorithm with starting vertex A
     * 
     * @return Edges of minimum spanning tree
     */
    ArrayList<Edge> kruskal() {
        int[] parent = new int[size]; // initialize parent set for union find.
        for (int i = 0; i < size; ++i) {
            parent[i] = i;
        }

        Edge[] es = new Edge[this.edges.length]; // initialize Array of all edges for greedy selection.
        for (int i = 0; i < es.length; ++i) {
            es[i] = new Edge(this.edges[i][0], this.edges[i][1], this.edges[i][2]);
        }
        Arrays.sort(es, new Comparator<Edge>() { // sort according to the cost of each edge.

            @Override
            public int compare(Edge e1, Edge e2) {
                return e1.dist - e2.dist;
            }

        });

        ArrayList<Edge> res = new ArrayList<>(); // result storing edges of minimum spanning tree
        // end of initialization.
        // Main loop
        for (int e = 0; e < es.length; ++e) { //
            int src = es[e].src; // selecting the smallest edge
            int end = es[e].end;
            if (find(parent, src) != find(parent, end)) { // check if two ends are in the same connected component.
                res.add(es[e]);  // if so then add it would create a cycle. 
                Union(parent, src, end); 
            }
        }
        int total_dist = 0;
        for (Edge e : res) {
            total_dist += e.dist;
        }
        System.out.println("kruskal total dist = " + total_dist);

        return res;
    }

    // main functions for performing all algorithms
    public static void main(String[] args) throws Exception {

        System.out.println("Graph algorithms tasks");

        int[][] edges = { { 0, 1, 2 }, { 1, 2, 15 }, { 0, 2, 5 }, { 0, 3, 30 }, { 1, 4, 8 }, { 3, 4, 4 }, { 3, 5, 10 },
                { 4, 5, 18 }, { 2, 5, 7 } };
        GraphAlgorithms new_algorithm = new GraphAlgorithms(edges, 6, false);
        var graph = new_algorithm.get_list();

        int[][] matrix = new_algorithm.get_matrix();

        for (int i = 0; i < 6; ++i) {
            for (int j = 0; j < 6; ++j) {
                System.out.print(matrix[i][j] + " ");
            }
            System.out.println("");
        }

        // BFS
        System.out.println("bfs: ");
        new_algorithm.bfs((top, b) -> {
            System.out.print(top + ",");
        });
        System.out.print("\n");

        // DFS
        System.out.println("dfs: ");
        new_algorithm.dfs((top, b) -> {
            System.out.print(top + ",");
        });

        var prim = new_algorithm.prim(0);
        var kruskal = new_algorithm.kruskal();

        System.out.println("Prim's result: ");
        for (Edge e : prim) {
            System.out.println("src = " + e.src + " end = " + e.end + " dist = " + e.dist);
        }

        System.out.println("Kruskal's result: ");
        for (Edge e : kruskal) {
            System.out.println("src = " + e.src + " end = " + e.end + " dist = " + e.dist);
        }

        edges = new int[][] { { 0, 3, 30 }, { 0, 2, 5 }, { 5, 3, 10 }, { 1, 0, 2 }, { 2, 1, 15 }, { 2, 5, 7 },
                { 1, 4, 8 }, { 4, 3, 4 }, { 5, 4, 18 } };
        new_algorithm = new GraphAlgorithms(edges, 6, true);
        new_algorithm.djikstra(0);

        // Topogological sort
        edges = new int[][] { { 0, 3, 1 }, { 0, 2, 1 }, { 2, 5, 1 }, { 2, 1, 1 }, { 1, 4, 1 }, { 5, 4, 1 }, { 5, 3, 1 },
                { 4, 3, 1 } };
        new_algorithm = new GraphAlgorithms(edges, 6, true);
        var sorted = new_algorithm.topological_sort();
        System.out.println("topological sort result");
        System.out.println(sorted.toString());

    }
}
