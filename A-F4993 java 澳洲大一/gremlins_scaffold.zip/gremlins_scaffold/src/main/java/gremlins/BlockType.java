package gremlins;

public enum BlockType {
    BrickWall,
    StoneWall,
    Wizard,
    Gremlin,
    Fireball,
    Slime,
    ExitDoor,
    Space;
}
