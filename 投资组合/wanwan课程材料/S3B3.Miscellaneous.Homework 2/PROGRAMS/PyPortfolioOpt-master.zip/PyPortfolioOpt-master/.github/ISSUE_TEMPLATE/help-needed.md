---
name: Help needed
about: If you have a question about how to use PyPortfolioOpt
title: How to [insert question]?
labels: question
assignees: ''

---

**What are you trying to do?**
Clear description of the problem you are trying to solve with PyPortfolioOpt

**What data are you using?**
What asset class, how many assets, how many data points. Preferably provide a sample of the dataset as a csv attachment.
