---
name: Installation Error
about: If you are having trouble installing
title: Could not install on Windows Anaconda [replace with your environment]
labels: packaging
assignees: ''

---

**Operating system, environment, python version**
e.g Windows, anaconda, python3.7

**What you tried**
pip install pyportfolioopt

**Error message**
```
Copy paste the terminal message here
```
