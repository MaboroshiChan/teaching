// CW Scheduling Processes.cpp : This file contains the 'main' function. Program execution begins and ends there.
// 

#include <iostream>
#include "Scheduler.h"
#include "Parameters.h"
#include <thread>
#include <list>

std::chrono::steady_clock::time_point current_time = std::chrono::steady_clock::now();

void InitClock()
{
	current_time = std::chrono::steady_clock::now();
}

int64_t GetTime()
{
	std::chrono::steady_clock::time_point new_time = std::chrono::steady_clock::now();
	return std::chrono::duration_cast<std::chrono::milliseconds>(new_time - current_time).count();
}

void myfunc(int n){
    std::cout << "n = " << n << "\n";
}

int main2(){
    std::list<int> queue;
    queue.push_back(1);
    queue.push_back(2);
    queue.push_front(0);
    queue.pop_back();
    for(int i : queue){ // print all elements in queue in order.
        std::cout << i << ", ";
    }
    std::cout << "\n";
    return 0;
}

int main()
{
    
    std::cout << "This is the main function\n";
	InitClock();
    std::thread t;
	for (int i = 0; i < NB_SIMULATION_REPEATS; i++)
	{
        //t = std::thread(myfunc, i);
        //t.detach();
		Scheduler s;
		s.ScheduleTasksUntilEnd();
#ifdef PRINT_TERMINATION_OUTPUT
		std::cout << "Average Simulation Time (s): " << ((float)GetTime()) / (i+1)/1000. << " s\n";
#endif
	}
	std::cout << "Average Simulation Time (s): " << ((float)GetTime()) / (NB_SIMULATION_REPEATS) / 1000. << " s\n";
    return 0;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
