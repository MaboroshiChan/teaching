#include "Scheduler.h"
#include <thread>

Scheduler::Scheduler() //Cosntructor function
{
	CreateEnvironment(); //Destructor function
};
Scheduler::~Scheduler() {
	for (int i = 0; i < NB_PROCESSORS; i++)
		processors[i].StopProcessor();
};

void Scheduler::CreateEnvironment()  //this function should not be modified
{
	//Spining up simulated processors that will be represented by threads
	for (int i = 0; i < NB_PROCESSORS; i++)
	{
		processors[i].SetID(i);
		processors[i].AttachScheduler(this); //Giving access to this scheduler in a Processor object (i.e., for NotifyEndScheduling)
		processors[i].StartProcessor();
	}

	//Initialising tasks
	for (int i = 0; i < NB_TASKS; i++)
		tasks[i].SetID(i);
};

// core of scheduling.
void Scheduler::ScheduleTasksUntilEnd(){
     // queue for free processors.
    /**
    for(int i = 0; i < NB_PROCESSORS; ++i){
        this->free_processors.push_back(i);
    }
    for(int i = 0; i < NB_TASKS;){ // iterate over task pool.
        while(!free_processors.empty()){
            int new_free_processor = free_processors.front();
            free_processors.pop_front();
            std::cout << "processor: " << new_free_processor << " poped\n";
            while(!processors[new_free_processor].LaunchTask(this->tasks[i])){}
            ++i;
        }
    }
    //TODO
     */
    
    for(int i = 0; i < NB_PROCESSORS; ++i){
        this->idle_processors.push_back(i); // set all processors to be free
    }
    
    for(int task_id = 0; task_id < NB_TASKS; ){
        
        while(!idle_processors.empty()){
            int new_free_cpu = idle_processors.front();
            idle_processors.pop_front();
            while(!processors[new_free_cpu].LaunchTask(this->tasks[task_id])){} // try to load new task until success.
            ++task_id;
        }
        
    }
}

void Scheduler::NotifyEndScheduling(int processor, int taskId, TaskState state){
    this->idle_processors.push_back(processor);
}
